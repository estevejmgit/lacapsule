import os
def print_length( str):
    print(len(str))
print_length("Hello world!")
